(function(){
  var STORAGE_KEY = "jism-lang";
  var html = document.documentElement;

  function setLang(lang){
    html.setAttribute("data-lang", lang);
    html.setAttribute("lang", lang);
    try{ localStorage.setItem(STORAGE_KEY, lang); }catch(e){}
    var buttons = document.querySelectorAll("[data-set-lang]");
    buttons.forEach(function(b){
      b.setAttribute("aria-pressed", b.getAttribute("data-set-lang") === lang ? "true" : "false");
    });
  }

  var saved = null;
  try{ saved = localStorage.getItem(STORAGE_KEY); }catch(e){}
  setLang(saved === "en" ? "en" : "ar"); // default Arabic

  document.addEventListener("click", function(e){
    var btn = e.target.closest("[data-set-lang]");
    if(btn){ setLang(btn.getAttribute("data-set-lang")); }
  });
})();
